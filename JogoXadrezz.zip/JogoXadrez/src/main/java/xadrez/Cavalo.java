/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xadrez;

/**
 *
 * @author gusta
 */
public class Cavalo extends Peca {
    
    @Override
    public void mover(){
    
        System.out.println("Andar em duas para frente e uma para o lado");
    
    }
    
}
