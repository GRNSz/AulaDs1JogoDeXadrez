/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jogoxadrez;

import xadrez.Bispo;
import xadrez.Cavalo;
import xadrez.Peao;
import xadrez.Peca;

/**
 *
 * @author gusta
 */
public class JogoXadrez {

    public static void main(String[] args) {
       Peca peao = new Peao();
       Peca cavalo = new Cavalo();
       Peca bispo = new Bispo();
       
       peao.mover();
       cavalo.mover();
       bispo.mover();
    }
}
